# The dependency graph

Twenty-two cross-module edges. Eleven of the twenty-nine stages carry none and chain only within their module, which is correct.

Consult this before starting any stage. An unmet precondition records as UNDEMONSTRATED. It is never skipped.

| From | To | Why |
|---|---|---|
| D2 corpus | P1 read sources | nothing is counted before the corpus and its exclusion ledger are published |
| D3 cut curve | P3 count every axis | clustering uses the measured cut, never a convention |
| D4 decision shape | P3 count every axis | **each root defines its own independent unit, so the seven axes count different objects under different roots** |
| D4 decision shape | I1 build compositions | the mechanical floor is built against the shape, and against the lifted task where a lift was recorded |
| D4 decision shape | P6 separation | the chance baseline follows from the root, and is k over candidates only under infer |
| D4 derived slots | P7 resolution | delta comes from the manifest, and MDE is meaningless without it |
| D5 ratification | R1 harness control | no paid work starts on an unratified manifest |
| R1 harness control | I1 build compositions | do not build instruments before a known-good subject completes the surface |
| P2 prior floor estimate | I1 build compositions | a floor that already takes the ceiling means there is nothing to build toward |
| I1 compositions | P6 separation | per-item separation is read off the two compositions |
| I1 compositions | P7 resolution | **the free variance estimate needs compositions in hand. Absent in the record, and the resolution limit went uncomputed for fourteen stages** |
| I2 channel count | P4 rule against bands | channel lift is the eighth axis. P4 refuses its final ruling while the axis is uncounted, and no arm runs on a provisional ruling |
| I2 channel count | R5 author gates | a grant carrying a channel closed at I2 arms only with a recorded lift |
| R3 load ladder | P7 resolution | the free variance is a lower bound on arm variance. The pilot cohort re-derives sigma_d, and R5 arms nothing on the provisional record |
| P6 separation | I5 certification | certify only the tools the surviving strata actually use |
| I5 certification | R4 grant verification | the grant advertises what certification admitted |
| I5 certification | R8 arm symmetry | **a current card must front the run. Absent in the record, and the scored comparison ran on a checkpoint 81 times too small** |
| I5 certification | A3 score paired | a stale card invalidates the numbers it produced |
| P7 resolution | A4 report | MDE is read from the power record, never restated |
| R4 grant verification | A3 score paired | a result read while grant reachability is undemonstrated is the recorded failure |
| R7 classify difference | A3 score paired | classify cosmetic or substantive before discarding any cell |
| R8 arm symmetry | A4 report | an unruled per-arm difference is a confound, not a result |

## The cycles

O1 re-enters D2, D3, D4, I1, I2 or P7 on a closure, and each re-entry is bounded by the router's guards: three remedies per candidate, two re-entries per stage, retirement after two failures. A re-entry is an amendment and recounts every axis downstream of the stage it enters.

R3 → P7 is not a cycle. P7 reads from I1 at its first pass and from R3 at its second, and points forward to A4 on both. P5 returns to P1. The queue is re-derived from observed yield and enumeration continues. Every other edge points forward.

Escape: the survivor count reaches S, or the optimistic bound on remaining supply falls below S.

## The one non-terminal edge

R1 back into the instrument module. A known-good subject failing at the harness control indicts the surface, never the subject. This is the only edge in the funnel that does not remove a candidate.
