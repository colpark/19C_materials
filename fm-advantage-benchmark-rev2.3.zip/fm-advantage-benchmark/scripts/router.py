#!/usr/bin/env python3
"""O1: route on closure. The orchestrator's decision policy, as code.

    python router.py route --closure P7_CLOSE_UNRESOLVABLE --candidate C1 \\
        --context context.json --manifest manifest.json --portfolio portfolio.json --out decision_001.json
    python router.py card decision_001.json
    python router.py next --portfolio portfolio.json

A closure names what bound (the key). The remedy table lists the moves that could
unbind it, in order. Each move is autonomous or reserved. The router launches the
autonomous moves whose preconditions hold and whose projected cost stays inside the
resource envelope's hard limit, refuses the rest with the reason, and writes one
decision record. Reserved moves go to the human on a decision card. Nothing blocks
on the card: the portfolio's next candidate keeps running.

Three guards bound the loops the router introduces: remedy depth per candidate
(distinct moves ever launched, portfolio moves excluded), re-entries per
(candidate, stage), and a retired list for a move that failed twice. No
autonomous move ever changes a preregistered element after outcomes were seen.

A launched move commits its projected cost. When it reports (`report`), the
commitment is released and the measured cost is booked as spent, and a move
that succeeded is marked satisfied so no later routing re-launches it or counts
it again. A decision issued on a stale envelope is voided (`void`), which rolls
back its commitments and its guard increments.

    python router.py report --portfolio portfolio.json --manifest manifest.json \
        --candidate C1 --remedy swap_fm_checkpoint --succeeded false --measured '{"gpu_hours": 1.5, "storage_gb": 1.4}'
    python router.py void decision_003.json --portfolio portfolio.json --manifest manifest.json
"""
import argparse, collections, json, sys

RESOURCES = ("gpu_hours", "storage_gb", "tokens_m", "wall_hours")
GUARDS = {"max_depth": 3, "max_reentry": 2, "max_failures": 2}

# ---------------------------------------------------------------- remedy table
# class: autonomous | reserved. reentry: the stage the move re-enters.
# needs: context keys that must be truthy. cost: projected spend per resource.
# prereg: True when the move changes a preregistered element; such a move is
# autonomous only before A1, and reserved to the human after outcomes are seen.
# depth_free: the move does not count toward the candidate's remedy depth, because it
# opens another candidate, moves the portfolio, or completes a move already counted.
DEPTH_FREE = {"spin_explain_candidate", "advance_next_candidate", "pool_libraries_new_tau"}
REMEDIES = {
  "search_sibling_libraries": dict(cls="autonomous", reentry="D2",
      cost=dict(gpu_hours=0, storage_gb=5, tokens_m=5, wall_hours=3), needs=[], prereg=False,
      what="search the corpus sources and public deposits for sibling libraries of the same task family, read whole, log to the exclusion ledger"),
  "pool_libraries_new_tau": dict(cls="autonomous", reentry="D3",
      cost=dict(gpu_hours=2, storage_gb=10, tokens_m=2, wall_hours=2), needs=["sibling_libraries_found"], prereg=False,
      what="pool the found libraries and re-measure tau; the unit may change, so the axis ledger is recounted"),
  "spin_explain_candidate": dict(cls="autonomous", reentry="D4",
      cost=dict(gpu_hours=0, storage_gb=1, tokens_m=3, wall_hours=2), needs=["heterogeneity_detected", "explain_grader_available"], prereg=False,
      what="open the explain candidate on the per-cluster channel effect, graded by the mechanical ablation floors at zero cells"),
  "buy_episodes_per_cluster": dict(cls="autonomous", reentry="P7",
      cost=dict(gpu_hours=1, storage_gb=1, tokens_m=4, wall_hours=6), needs=["items_bound", "unburned_supply"], prereg=False,
      what="enlarge the cohort from unburned supply so the within-cluster component shrinks; re-run the final P7 pass"),
  "swap_fm_checkpoint": dict(cls="autonomous", reentry="I2",
      cost=dict(gpu_hours=6, storage_gb=20, tokens_m=1, wall_hours=4), needs=["alt_fms"], prereg=False,
      what="precompute the alternative checkpoint on the same structures, rebuild the composition, re-run lift.py"),
  "change_role_scorer_lift": dict(cls="autonomous", reentry="I1",
      cost=dict(gpu_hours=1, storage_gb=1, tokens_m=2, wall_hours=3), needs=["agent_input_possible", "before_a1"], prereg=True,
      what="move the channel from predictor to scorer on agent-built inputs, rebuild the floor for the lifted task"),
  "forced_consultation_lift": dict(cls="autonomous", reentry="I1",
      cost=dict(gpu_hours=1, storage_gb=1, tokens_m=3, wall_hours=3), needs=["before_a1"], prereg=True,
      what="require consultation with a written verdict, rebuild the floor as the mechanical consultation"),
  "filter_by_exposure_key": dict(cls="autonomous", reentry="D2",
      cost=dict(gpu_hours=0, storage_gb=1, tokens_m=1, wall_hours=1), needs=["exposure_key_exists"], prereg=False,
      what="keep only items whose deposition postdates every subject's cutoff; recount the axis ledger"),
  "advance_next_candidate": dict(cls="autonomous", reentry="portfolio",
      cost=dict(gpu_hours=0, storage_gb=0, tokens_m=0, wall_hours=0), needs=["portfolio_has_next"], prereg=False,
      what="start the next active candidate in the portfolio by priority"),
  "request_new_libraries": dict(cls="reserved", reentry="D2",
      cost=dict(gpu_hours=0, storage_gb=0, tokens_m=0, wall_hours=0), needs=[], prereg=False,
      what="ask collaborators for libraries or new experiments; a scientific and programme decision"),
  "change_task_budget": dict(cls="reserved", reentry="D4",
      cost=dict(gpu_hours=1, storage_gb=1, tokens_m=1, wall_hours=2), needs=[], prereg=True,
      what="set the per-item measurement budget from what a campaign affords; cost of action belongs to the PI"),
  "different_scored_quantity": dict(cls="reserved", reentry="D4",
      cost=dict(gpu_hours=0, storage_gb=0, tokens_m=0, wall_hours=0), needs=[], prereg=True,
      what="move to a task whose scored quantity the FM's construct measures; a change of scientific question"),
  "accept_proxy_grader": dict(cls="reserved", reentry="I4",
      cost=dict(gpu_hours=0, storage_gb=0, tokens_m=0, wall_hours=0), needs=[], prereg=True,
      what="accept a disclosed proxy grader; a judgment about what counts as evidence"),
  "later_data": dict(cls="reserved", reentry="D2",
      cost=dict(gpu_hours=0, storage_gb=0, tokens_m=0, wall_hours=0), needs=[], prereg=False,
      what="wait for data deposited after the subject cutoff"),
  "escalate_rung_7": dict(cls="reserved", reentry="R1",
      cost=dict(gpu_hours=0, storage_gb=0, tokens_m=0, wall_hours=0), needs=[], prereg=False,
      what="the ladder's last rung: a harness fault no rule covers"),
}

# closure key -> ordered remedies. Supply closures split by what the variance says.
TABLE = {
  "I2_CLOSE":                 ["swap_fm_checkpoint", "change_role_scorer_lift", "advance_next_candidate", "different_scored_quantity"],
  "I4_FAIL":                  ["swap_fm_checkpoint", "advance_next_candidate", "different_scored_quantity", "accept_proxy_grader"],
  "SUPPLY_CLUSTERS":          ["search_sibling_libraries", "pool_libraries_new_tau", "spin_explain_candidate", "advance_next_candidate", "request_new_libraries", "change_task_budget"],
  "SUPPLY_ITEMS":             ["buy_episodes_per_cluster", "forced_consultation_lift", "advance_next_candidate", "change_task_budget"],
  "P2_CEILING":               ["advance_next_candidate", "change_task_budget"],
  "P3_CONTAMINATION":         ["filter_by_exposure_key", "advance_next_candidate", "later_data"],
  "R_STALL":                  ["advance_next_candidate", "escalate_rung_7"],
  "A4_NO_CLAIM_AT_LIMIT":     ["buy_episodes_per_cluster", "search_sibling_libraries", "spin_explain_candidate", "advance_next_candidate", "request_new_libraries", "change_task_budget"],
}


def closure_key(closure, ctx):
    """Map a stage ruling onto a table key, splitting supply closures by the variance decomposition."""
    c = closure.upper()
    if c in ("P7_CLOSE_UNRESOLVABLE", "P4_CLOSE", "P4_CLOSE_SUPPLY"):
        return "SUPPLY_CLUSTERS" if ctx.get("var_between_share", 1.0) >= 0.3 or ctx.get("n_min_clusters", 0) > ctx.get("n_clusters", 0) else "SUPPLY_ITEMS"
    if c.startswith("I2"): return "I2_CLOSE"
    if c.startswith("I4"): return "I4_FAIL"
    if c.startswith("P2"): return "P2_CEILING"
    if c.startswith("P3"): return "P3_CONTAMINATION"
    if c.startswith("R"): return "R_STALL"
    if c.startswith("A4"): return "A4_NO_CLAIM_AT_LIMIT"
    raise SystemExit(f"no table entry for closure {closure!r}")


def envelope_fit(env, cost):
    """Return (fits_hard, over_soft, projected) for a move's cost against the envelope."""
    tol = env.get("tolerance", 3.0); projected = {}; fits = True; over_soft = False
    for r in RESOURCES:
        ceiling = env[r]["ceiling"]; spent = env[r].get("spent", 0) + env[r].get("committed", 0)
        p = spent + cost.get(r, 0); projected[r] = p
        if p > ceiling * tol: fits = False
        if p > ceiling: over_soft = True
    return fits, over_soft, projected


def route(closure, candidate, ctx, manifest, portfolio):
    """The decision. Pure function of its inputs plus the guard state carried in the portfolio."""
    key = closure_key(closure, ctx)
    env = manifest["envelope"]; rights = manifest.get("decision_rights", {})
    delegated = set(rights.get("delegated", REMEDIES.keys()))
    standing = rights.get("standing", {})          # remedy -> {"ruling": approve|deny|defer, "source": ..., "scope": ..., "until": ...}
    halt_on = set(rights.get("halt_on", []))       # reserved moves whose unanswered card halts the run
    state = portfolio.setdefault("guard_state", {}).setdefault(candidate, {"depth": 0, "reentry": {}, "failures": {}, "retired": [], "launched_history": [], "completed": {}})
    state.setdefault("launched_history", []); state.setdefault("completed", {})
    state["depth"] = len([m for m in state["launched_history"] if m not in DEPTH_FREE])
    after_outcomes = bool(ctx.get("outcomes_seen", False))
    ctx = dict(ctx); ctx["before_a1"] = not after_outcomes
    ctx["portfolio_has_next"] = any(c["status"] == "active" and c["id"] != candidate for c in portfolio.get("candidates", []))

    launched, carded, refused = [], [], []
    guard_delta = {"reentry": {}, "launched": []}
    standing_applied, halt = [], False
    remedies = TABLE[key]
    reentered = set()
    for rid in remedies:
        r = REMEDIES[rid]
        fits, over_soft, projected = envelope_fit(env, r["cost"])
        missing = [n for n in r["needs"] if not ctx.get(n)]
        entry = {"remedy": rid, "class": r["cls"], "reentry": r["reentry"], "what": r["what"], "cost": r["cost"]}
        if rid in state["retired"]:
            refused.append({**entry, "reason": "retired: failed twice for this candidate"}); continue
        done = state["completed"].get(rid)
        if done and done.get("succeeded"):
            refused.append({**entry, "reason": "already completed successfully for this candidate; its result is in the context"}); continue
        if rid in state["launched_history"] and rid not in state["completed"] and r["reentry"] != "portfolio":
            refused.append({**entry, "reason": "launched earlier and not yet reported; wait for the outcome"}); continue
        new_move = rid not in state["launched_history"] and rid not in DEPTH_FREE
        if new_move and state["depth"] >= GUARDS["max_depth"]:
            refused.append({**entry, "reason": f"remedy depth {state['depth']} reached the guard for this candidate"}); continue
        reserved_now = (r["cls"] == "reserved" or rid not in delegated) or (r["prereg"] and after_outcomes)
        why_reserved = ("reserved to the human by the decision rights" if (r["cls"] == "reserved" or rid not in delegated)
                        else "changes a preregistered element after outcomes were seen; reserved")
        if reserved_now:
            st_r = standing.get(rid)
            if st_r and st_r.get("ruling") == "approve":
                standing_applied.append({"remedy": rid, "ruling": "approve", "source": st_r.get("source", "unknown"), "scope": st_r.get("scope", "")})
                entry["standing"] = f"approved by standing ruling ({st_r.get('source', 'unknown')})"
            elif st_r and st_r.get("ruling") == "deny":
                refused.append({**entry, "reason": f"denied by standing ruling ({st_r.get('source', 'unknown')})"}); continue
            elif st_r and st_r.get("ruling") == "defer":
                carded.append({**entry, "reason": f"deferred by standing ruling until {st_r.get('until', 'the end of the pass')}; does not halt"}); continue
            else:
                if rid in halt_on: halt = True
                carded.append({**entry, "reason": why_reserved + (". HALTS the run" if rid in halt_on else "")}); continue
        if missing:
            refused.append({**entry, "reason": f"precondition not met: {', '.join(missing)}"}); continue
        if not fits:
            carded.append({**entry, "reason": "projected spend exceeds the envelope's hard limit; needs a human", "projected": projected}); continue
        if state["reentry"].get(r["reentry"], 0) >= GUARDS["max_reentry"] and r["reentry"] != "portfolio":
            refused.append({**entry, "reason": f"stage {r['reentry']} already re-entered {GUARDS['max_reentry']} times for this candidate"}); continue
        if r["reentry"] in reentered:
            refused.append({**entry, "reason": f"stage {r['reentry']} already re-entered by an earlier move in this decision"}); continue
        # launch: commit the cost, count the re-entry, flag soft overruns, record the delta for a possible void
        for res in RESOURCES: env[res]["committed"] = env[res].get("committed", 0) + r["cost"].get(res, 0)
        if r["reentry"] != "portfolio":
            state["reentry"][r["reentry"]] = state["reentry"].get(r["reentry"], 0) + 1
            guard_delta["reentry"][r["reentry"]] = guard_delta["reentry"].get(r["reentry"], 0) + 1
        if rid not in state["launched_history"]:
            state["launched_history"].append(rid); guard_delta["launched"].append(rid)
        reentered.add(r["reentry"])
        launched.append({**entry, "over_soft_ceiling": over_soft, "projected": projected})
    state["depth"] = len([m for m in state["launched_history"] if m not in DEPTH_FREE])
    rec = {"closure": closure, "key": key, "candidate": candidate, "outcomes_seen": after_outcomes,
           "launched": launched, "carded": carded, "refused": refused,
           "standing_applied": standing_applied, "halt": halt,
           "guard_state": dict(state), "guard_delta": guard_delta, "envelope_after": {r: dict(env[r]) for r in RESOURCES},
           "amendments": [f"O1: {l['remedy']} re-enters {l['reentry']} for {candidate}" for l in launched],
           "completeness": (f"routed {closure} as {key} for {candidate}: {len(launched)} launched, {len(carded)} carded to the human, "
                            f"{len(refused)} refused, {len(standing_applied)} standing rulings applied, depth {state['depth']} of {GUARDS['max_depth']}"
                            + (", HALT" if halt else ""))}
    return rec


def report_outcome(portfolio, candidate, remedy, succeeded, manifest=None, measured=None):
    """A move reports. Release its commitment, book what it measured, record the completion."""
    st = portfolio["guard_state"][candidate]
    st.setdefault("completed", {})[remedy] = {"succeeded": bool(succeeded), "measured": measured or {}}
    if manifest is not None:
        env = manifest["envelope"]; cost = REMEDIES[remedy]["cost"]
        for res in RESOURCES:
            env[res]["committed"] = max(0.0, env[res].get("committed", 0) - cost.get(res, 0))
            env[res]["spent"] = env[res].get("spent", 0) + (measured or {}).get(res, cost.get(res, 0))
    if not succeeded:
        st["failures"][remedy] = st["failures"].get(remedy, 0) + 1
        if st["failures"][remedy] >= GUARDS["max_failures"] and remedy not in st["retired"]: st["retired"].append(remedy)


def void(decision, portfolio, manifest):
    """Roll back a decision issued on a stale envelope: its commitments and its guard increments."""
    cand = decision["candidate"]; st = portfolio["guard_state"][cand]; env = manifest["envelope"]
    for l in decision.get("launched", []):
        cost = REMEDIES[l["remedy"]]["cost"]
        for res in RESOURCES: env[res]["committed"] = max(0.0, env[res].get("committed", 0) - cost.get(res, 0))
    for stage, n in decision.get("guard_delta", {}).get("reentry", {}).items():
        st["reentry"][stage] = max(0, st["reentry"].get(stage, 0) - n)
    for rid in decision.get("guard_delta", {}).get("launched", []):
        if rid in st["launched_history"] and rid not in st.get("completed", {}): st["launched_history"].remove(rid)
    st["depth"] = len([m for m in st["launched_history"] if m not in DEPTH_FREE])
    decision["voided"] = True
    return decision


def next_candidate(portfolio):
    """Highest-priority active candidate: resolving power first, cost class to break ties."""
    act = [c for c in portfolio.get("candidates", []) if c["status"] == "active"]
    if not act: return None
    return sorted(act, key=lambda c: (-c.get("resolving_power", 0), c.get("cost_class", 9)))[0]


def card(rec):
    lines = [f"# Decision card: {rec['closure']} on {rec['candidate']}" + ("  [RUN HALTED]" if rec.get("halt") else ""), ""]
    if rec.get("standing_applied"):
        lines += ["Applied from your standing rulings:"] + [f"- {s['remedy']}: {s['ruling']} ({s['source']})" for s in rec["standing_applied"]] + [""]
    if rec["launched"]:
        lines += ["Running now, no decision needed:"] + [f"- {l['remedy']} (re-enters {l['reentry']}): {l['what']}" for l in rec["launched"]] + [""]
    if rec["carded"]:
        lines += ["Your decisions:"] + [f"- {c['remedy']}: {c['what']}. Why you: {c['reason']}" for c in rec["carded"]] + [""]
    if rec["refused"]:
        lines += ["Not taken:"] + [f"- {r['remedy']}: {r['reason']}" for r in rec["refused"]] + [""]
    lines.append(rec["completeness"])
    return "\n".join(lines)


def main():
    p = argparse.ArgumentParser(); sub = p.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("route"); r.add_argument("--closure", required=True); r.add_argument("--candidate", required=True)
    r.add_argument("--context", required=True); r.add_argument("--manifest", required=True); r.add_argument("--portfolio", required=True)
    r.add_argument("--out")
    c = sub.add_parser("card"); c.add_argument("decision")
    n = sub.add_parser("next"); n.add_argument("--portfolio", required=True)
    rp = sub.add_parser("report"); rp.add_argument("--portfolio", required=True); rp.add_argument("--manifest", required=True)
    rp.add_argument("--candidate", required=True); rp.add_argument("--remedy", required=True)
    rp.add_argument("--succeeded", required=True, choices=["true", "false"]); rp.add_argument("--measured", default="{}")
    v = sub.add_parser("void"); v.add_argument("decision"); v.add_argument("--portfolio", required=True); v.add_argument("--manifest", required=True)
    a = p.parse_args()
    if a.cmd == "route":
        ctx = json.load(open(a.context)); man = json.load(open(a.manifest)); pf = json.load(open(a.portfolio))
        rec = route(a.closure, a.candidate, ctx, man, pf)
        json.dump(pf, open(a.portfolio, "w"), indent=2); json.dump(man, open(a.manifest, "w"), indent=2)
        txt = json.dumps(rec, indent=2)
        if a.out: open(a.out, "w").write(txt + "\n")
        print(txt); print("\n" + card(rec), file=sys.stderr)
        return 0
    if a.cmd == "card":
        print(card(json.load(open(a.decision)))); return 0
    if a.cmd == "next":
        nxt = next_candidate(json.load(open(a.portfolio)))
        print(json.dumps(nxt, indent=2) if nxt else "no active candidate"); return 0
    if a.cmd == "report":
        pf = json.load(open(a.portfolio)); man = json.load(open(a.manifest))
        report_outcome(pf, a.candidate, a.remedy, a.succeeded == "true", man, json.loads(a.measured))
        json.dump(pf, open(a.portfolio, "w"), indent=2); json.dump(man, open(a.manifest, "w"), indent=2)
        print(json.dumps({"candidate": a.candidate, "remedy": a.remedy, "succeeded": a.succeeded == "true",
                          "envelope": {r: man["envelope"][r] for r in RESOURCES}, "guard_state": pf["guard_state"][a.candidate]}, indent=2)); return 0
    if a.cmd == "void":
        d = json.load(open(a.decision)); pf = json.load(open(a.portfolio)); man = json.load(open(a.manifest))
        void(d, pf, man)
        json.dump(pf, open(a.portfolio, "w"), indent=2); json.dump(man, open(a.manifest, "w"), indent=2)
        json.dump(d, open(a.decision, "w"), indent=2)
        print(json.dumps({"voided": a.decision, "guard_state": pf["guard_state"][d["candidate"]], "envelope": {r: man["envelope"][r] for r in RESOURCES}}, indent=2)); return 0


if __name__ == "__main__": raise SystemExit(main())
